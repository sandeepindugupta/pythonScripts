const workflowTypeCard = require('./AdaptiveCards/Workflow_queries_types.json');
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const {ActivityTypes,MessageFactory,TurnContext} = require('botbuilder');
const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const { ConfirmPrompt, TextPrompt,NumberPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
// const { DateResolverDialog } = require('./dateResolverDialog');
const { CardFactory } = require('botbuilder-core');
const { workflowEntityCheck } = require('./workflowEntityCheck');
const AddressTypes = require('./AdaptiveCards/AddressTypes.json');
const finance_card = require('./AdaptiveCards/financeData.json');
const CONFIRM_PROMPT = 'confirmPrompt';
// const DATE_RESOLVER_DIALOG = 'dateResolverDialog';
const TEXT_PROMPT = 'textPrompt';
const WATERFALL_DIALOG = 'waterfallDialog';
const WORKFLOWENTITYCHECK = 'workflowEntityCheck';
const NUMBER_PROMPT='numberprompt';
class workflowDataUpdate extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'workflowDataUpdate');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(NUMBER_PROMPT))
            .addDialog(new workflowEntityCheck(WORKFLOWENTITYCHECK))
            // .addDialog(new DateResolverDialog(DATE_RESOLVER_DIALOG))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [               
				this.EntityID.bind(this),
                 this.workflowType.bind(this),
                this.workflowDetails.bind(this),               
                this.confirmStep.bind(this), 
                this.finalStep.bind(this),        
				
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

    
 async EntityID(stepContext) {
        const bookingDetails = stepContext.options;
        console.log("sdfsdf", bookingDetails.entity_id_value);
         if (!bookingDetails.entity_id_value || (bookingDetails.entity_id_value).length != 8) {
             console.log("entity fucntion");
            return await stepContext.beginDialog("workflowEntityCheck", { entityID: bookingDetails.entity_id_value });
            
         }
         else
         {
             return await stepContext.next(bookingDetails.entity_id_value);
         }
 }

   
  async workflowType(stepContext) {
        const bookingDetails = stepContext.options;
       console.log("financeTypeEEEEE functiom:@",stepContext.options);
        // Capture the response to the previous step's prompt
        bookingDetails.entityID = stepContext.result;
        console.log("Step contxet****",stepContext.result);
        if (!bookingDetails.workflowType) {
            console.log("insideTTTTT types");
             const workflowCard = CardFactory.adaptiveCard(workflowTypeCard);
          await stepContext.context.sendActivity({attachments: [workflowCard] });
           return await stepContext.prompt('textPrompt', '');


        } 
    
        else {
            return await stepContext.next(bookingDetails.workflow_type_value);
        }
       
    }
    
    async workflowDetails(stepContext) {
        const bookingDetails = stepContext.options;

        bookingDetails.workflow_type_value = stepContext.result;
        console.log("stepContext.result in address$$",stepContext.result);
        if (!bookingDetails.workflowDetails) {
            return await stepContext.prompt(TEXT_PROMPT, { prompt: 'Please write short description on '+`**${bookingDetails.workflow_type_value.toLowerCase()}**`+" issue" +' \nPlease type or paste it in full.' });
            
        } else {
            return await stepContext.next(bookingDetails.workflowDetails_value);
            
        }
    }
    async confirmStep(stepContext) {
        const bookingDetails = stepContext.options;

        bookingDetails.workflowDetails_value = stepContext.result;
      
        
        const Text = [
                     ];
const card = CardFactory.heroCard('', undefined,
            Text, { text:"Thanks,this is what you’hv told me:\n\n**Issue on workflow data** \n\n**Entity ID** \t\t: "+ bookingDetails.entityID +'\n\n **Workflow Issue**:\t\t'+bookingDetails.workflow_type_value +'\n\n **Workflow issue discription**:\t\t'+ bookingDetails.workflowDetails_value +'\n\n **Do you want to submit this request?**' + '' });
return await stepContext.prompt(CONFIRM_PROMPT, { prompt: { attachments: [card] } });
   
    }

    async finalStep(stepContext) {
        console.log("final step is : ",stepContext.result);
        if (stepContext.result === true) {
            const bookingDetails = stepContext.options;

            return await stepContext.endDialog(bookingDetails);
        } else {
            return await stepContext.endDialog();
        }
    }
}

module.exports.workflowDataUpdate = workflowDataUpdate;