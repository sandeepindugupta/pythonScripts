// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const {ActivityTypes,MessageFactory,TurnContext,BotFrameworkAdapter, MemoryStorage, ConversationState, UserState } = require('botbuilder');
const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const { ComponentDialog, DialogSet, DialogTurnStatus, TextPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { ActivityHandler } = require('botbuilder');
const { EntityEditorsUpdate } = require('./EntityEditorsUpdate');
const { LuisHelper } = require('./luisHelper');
const {addressUpdate}=require('./addressUpdate');
const{ cmsUpdate}=require('./cmsUpdate');
const {financeDataUpdate}=require('./financeDataUpdate');
const {taxDataUpdate}=require('./taxDataUpdate');
const {workflowDataUpdate}=require('./workflowDataUpdate');
const {statusCode}= require('./statusCode');
const {starmind}= require('./starmind');
const welcome_LEM = require('./AdaptiveCards/Lem_NewWelcome.json');
const { CardFactory } = require('botbuilder-core');
const MAIN_WATERFALL_DIALOG = 'mainWaterfallDialog';
const TEXT_PROMPT = 'textPrompt';
const ENTITY_EDITORS_UPDATE = 'EntityEditorsUpdate';
const ADDRESS_UPDATE='addressUpdate';
const CMS_UPDATE='cmsUpdate';
const FINANCE_DATA_UPDATE='financeDataUpdate';
const TAX_DATA_UPDATE='taxDataUpdate';
const WORKFLOW_DATA_UPDATE='workflowDataUpdate';
const STATUS_CODE='statusCode';
const STARMIND='starmind';
const Many = require('extends-classes');
var https=require('https');
const PRIVATE_CONVERSATION_DATA_PROPERTY = 'privateconversationData';
// const CONVERSATION_DATA_PROPERTY = 'conversationData';
// const USER_PROFILE_PROPERTY = 'userProfile';
class MainDialog extends ComponentDialog {
    constructor(logger,privateconversationState,conversationState, userState) {
        super('MainDialog');
        this.privateconversationData = privateconversationState.createProperty(PRIVATE_CONVERSATION_DATA_PROPERTY);
		this.privateconversationState = privateconversationState;
        //  this.conversationData = conversationState.createProperty(CONVERSATION_DATA_PROPERTY);
        // this.userProfile = userState.createProperty(USER_PROFILE_PROPERTY);
        
        // this.conversationState = conversationState;
        // this.userState = userState;

        if (!logger) {
            logger = console;
            logger.log('[MainDialog]: logger not passed in, defaulting to console');
        }

        this.logger = logger;

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new EntityEditorsUpdate(ENTITY_EDITORS_UPDATE))
            .addDialog(new addressUpdate(ADDRESS_UPDATE))
            .addDialog(new cmsUpdate(CMS_UPDATE))
            .addDialog(new financeDataUpdate(FINANCE_DATA_UPDATE))
            .addDialog(new taxDataUpdate(TAX_DATA_UPDATE))
            .addDialog(new workflowDataUpdate(WORKFLOW_DATA_UPDATE))
            .addDialog(new statusCode(STATUS_CODE))
            .addDialog(new starmind(STARMIND))
            .addDialog(new WaterfallDialog(MAIN_WATERFALL_DIALOG, [
            this.actStep.bind(this),
            this.finalStep.bind(this)
        ]));

        this.initialDialogId = MAIN_WATERFALL_DIALOG;
    }


    /**
     * The run method handles the incoming activity (in the form of a DialogContext) and passes it through the dialog system.
     * If no dialog is active, it will start the default dialog.
     * @param {*} dialogContext
     */
    async run(turnContext, accessor) {
    const dialogSet = new DialogSet(accessor);
    dialogSet.add(this);

    const dialogContext = await dialogSet.createContext(turnContext);
    const results = await dialogContext.continueDialog();



    console.log("status result", results.status);
    console.log("status result", DialogTurnStatus.empty);

    if (results.status === DialogTurnStatus.empty) {
        await dialogContext.beginDialog(this.id);
    }
}
    async actStep(stepContext) {
        let bookingDetails = {};
          const privateconversationData = await this.privateconversationData.get(stepContext.context, {});
		 console.log("privateconversationData",privateconversationData);
         privateconversationData.data="bookingDetails.intent";
         console.log("privateconversationData session",privateconversationData.data);
        let bookingDetails1 = {};
        console.log("Inside actstep :::flow 3", bookingDetails.intent);
        


const https = require('https');

const options = {
  hostname: 'swissre.starmind.com',
  port: 443,
  path: '/',
  method: 'POST'
};

const req = https.request(options, (res) => {
  console.log('statusCode:', res.statusCode);
  console.log('headers:', res.headers);

  res.on('data', (d) => {
    process.stdout.write(d);
  });
});

req.on('error', (e) => {
  console.error(e);
});
req.end();


 console.log("done API33333333333333333");
        if (process.env.LuisAppId && process.env.LuisAPIKey && process.env.LuisAPIHostName) {
            console.log("Inside Luis ");
            bookingDetails = await LuisHelper.executeLuisQuery(this.logger, stepContext.context);

            this.logger.log('LUIS extracted these booking details:', bookingDetails);
        }

        if (bookingDetails.intent == 'LEM_Queries') {
            
            return await stepContext.endDialog();
        }
        // else if (bookingDetails.intent == 'Legal_entitty_bsns_issues') {
        //     const Issues_LE_bsns_data1 = CardFactory.adaptiveCard(Issues_LE_bsns_data);
        //     return await stepContext.context.sendActivity({ attachments: [Issues_LE_bsns_data1] });
            
        // }
         else if (bookingDetails.intent == "Entity_data_updation") {
            return await stepContext.endDialog();
        } 
      
        // else if (bookingDetails.intent == 'Other_LEM/LPE_data_issue') {
        //     return await stepContext.endDialog();
          
        // }
        
        else if (bookingDetails.intent == 'Entity_address') {
             console.log("csm updation3");
            return await stepContext.beginDialog("addressUpdate", bookingDetails);


        }
         else if (bookingDetails.intent == 'FAQs_related_to_LEM') {
            
        return await stepContext.beginDialog("starmind", bookingDetails);

        }
         else if (bookingDetails.intent == 'EntityEditorsUpdate') {

            return await stepContext.beginDialog("EntityEditorsUpdate", bookingDetails);


        }
        //***** CMS Updation****
         else if (bookingDetails.intent == 'Entity_CMS') {
             console.log("csm updation");




            return await stepContext.beginDialog("cmsUpdate", bookingDetails);


        }
        else if (bookingDetails.intent == "Entity_finance") {
          return await stepContext.beginDialog("financeDataUpdate", bookingDetails);
            
            
        
        }else if (bookingDetails.intent == "Workflow_queries") {
           return await stepContext.beginDialog("workflowDataUpdate", bookingDetails);
        
        }
        
         else if (bookingDetails.intent == "tax_data") {
            return await stepContext.beginDialog("taxDataUpdate", bookingDetails);
        }
        
         
        // else if (bookingDetails.intent == 'general_queries'){
        //      return await stepContext.endDialog();            
        // }
        else if (bookingDetails.intent == "None") {
            
            let text_value;
           text_value = stepContext.context.activity.text;
           // here we are getting ticket details 
            console.log("7777777777", text_value);
            
            if (stepContext.context.activity.text)
            { 
                // creating random number
                 var x = Math.floor((Math.random() * 90000000) + 10000000);
                   var requestId="RITM"+x;
                   
                if(stepContext.context.activity.text.toLowerCase()=="yes"){
                  const welcome_again = CardFactory.adaptiveCard(welcome_LEM);
                  return await stepContext.context.sendActivity({ attachments: [welcome_again] });  
                }else if(stepContext.context.activity.text.toLowerCase()=="no"){
                  // stepContext.context.sendActivity("Thank you.Have a nice day! ");
                  return await stepContext.endDialog();  
                }
                //handling cancel from welcome message 
                
                else if(stepContext.context.activity.text.toLowerCase()=="cancel"){
                   console.log("inside cancel");
                  
                 var json=   {
                                "action": "handover"
                                
                            }
              console.log("inside cancel");
              var json1=JSON.stringify(json);
              await stepContext.context.sendActivity(json1);
                    
       
                    
                }
                //ckecking with status code 
                else if(text_value.includes("code"))
                {                    
                    return await stepContext.beginDialog("statusCode", stepContext.context.activity.text);   
                }
                else{
                    
                    // Sorry message use case
                   
                    var json={
                        
                             "action": "handover",
                             "message": stepContext.context.activity.text , 
                             "request_id":requestId,
                             "reason": 4 


                    }
                    var json1=JSON.stringify(json);
                console.log("sorry message");
                stepContext.context.sendActivity(json1);
                // stepContext.context.sendActivity("I’m sorry, I don’t understand the question. Could you please try rephrasing it so that I can better assist you? I want to help.");
                return await stepContext.endDialog();
                }
            }
          
        //   if (stepContext.context.activity.value !== undefined)
        //   {
        //       console.log("Comment value is: ", stepContext.context.activity.value.comment);
        //   if (stepContext.context.activity.value.entityId !== '' && stepContext.context.activity.value.entityId !== undefined && stepContext.context.activity.value.entityName!== '' && stepContext.context.activity.value.entityName!== undefined && stepContext.context.activity.value.comment!=='' && stepContext.context.activity.value.comment!==undefined ) {
        
                
        //         //check for Tax jurisdiction data value
        //         const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
        //          Api_input_values.entityId = stepContext.context.activity.value.entityId;
        //         Api_input_values.entityName = stepContext.context.activity.value.entityName;
        //         Api_input_values.comment=stepContext.context.activity.value.comment;
        //         console.log("API call inside comment", Api_input_values);
        //         stepContext.context.sendActivity(`ContactOne ticket has been created successfully. Support team will contact you shortly.`);
        //         await timeout(3000); 
                
               
        //          return await stepContext.endDialog();              
        //   }
          
          
                     
            
        // }
        //     return await stepContext.endDialog();
        } else 
        {
            return await stepContext.endDialog();
        }

    }


async finalStep(stepContext) {
    if (stepContext.result) {
        console.log("privateconversationData in final step",privateconversationData.data);
        console.log("initating starmind%%%");
        var request = require("request");
// var options = { method: 'POST',
//   url: 'https://swissre.starmind.com/api/v1/auth/login',
//   qs: { '': '' },
//   headers: 
//    { 'cache-control': 'no-cache',
//        timeout: 3000,
//      Connection: 'keep-alive',
    
//      'accept-encoding': 'gzip, deflate',
//      Host: 'swissre.starmind.com',
//      'Postman-Token': 'df7ddd08-3ef7-4cbb-a5c5-3a68f972cabc,395c19b7-81d5-4c2a-926f-f221b68a7051',
//      'Cache-Control': 'no-cache',
//      Accept: '*/*',
//      'User-Agent': 'PostmanRuntime/7.11.0',
//      'X-Auth-ApiKey': 'kjhb2342398z423hjvx234xjhnkjoiuo34',
//      'Content-Type': 'application/json' },
//   body: 
//    { email: 'TECDRRT1_Service@swissre.com',
//      password: 'poiu234nklklj2469lkj' },
//   json: true };
// request.on('timeout', () => {
//     request.abort();
// });

// // const request = http.request(options, response => 
// const req = http.req(options, function (error, response, body) {
  
//   if (error) throw new Error(error);

//   console.log("Sandeeep gupta",body);
// });
// req.on('timeout', () => {
//    socket.setTimeout(myTimeout);
//     req.abort();
// });



var request = require("request");

var options = { method: 'POST',
  url: 'https://swissre.starmind.com/api/v1/auth/login',
  headers: 
   { 'cache-control': 'no-cache',
     Connection: 'keep-alive',
     // 'content-length': '80',
     'accept-encoding': 'gzip, deflate',
     Host: 'swissre.starmind.com',
     'Postman-Token': '42a00f55-a555-4f89-aa6e-ff987f12a9ac,2634beda-90c2-414e-ab6e-f7b41de24b8e',
     'Cache-Control': 'no-cache',
     'User-Agent': 'PostmanRuntime/7.15.0',
     'Content-Type': 'application/json',
     'X-Auth-ApiKey': 'kjhb2342398z423hjvx234xjhnkjoiuo34',
     Accept: 'application/json' },
  body: 
   { email: 'TECDRRT1_Service@swissre.com',
     password: 'poiu234nklklj2469lkj' },
  json: true };

request(options, function (error, response, body) {
  if (error) throw new Error(error);

  console.log("Sandeeeep",body);
});

        

console.log("done API");
      
        
        
        const result = stepContext.result;
        // Now we have all the booking details.
        var x = Math.floor((Math.random() * 90000000) + 10000000);
       var requestId="RITM"+x;
        console.log("request id",requestId);
    // console.log("flow 4 final step",stepContext);
    if(result.intent=='Entity_address'){
          var  newAddressType;
        if (result.address_type_value.toLowerCase().startsWith ("update"))
        {
           
             newAddressType=result.address_type_value.slice(7,);
             console.log("inside main final if condition",newAddressType);
        }
        else
        {
            newAddressType=result.address_type_value;
        }
         
         var shortDesc="I want to update my " +`${newAddressType}` + " following are details:-"+"entityId : "+`${result.entityID}`+",New "+`${newAddressType}`+":"+`${result.address}`;
         var json={
            "action": "create_ops_ticket",
            "state": "1",
             "call_code": "ContactOne bot",
             "assignment_group": "assignment group",
             "priority": 4,
             "category": "inquiry",
            "short_description":shortDesc,
            "request_id":requestId,
             "reason": 1            
        }
        
    }
    else if(result.intent=='tax_data'){
          var  newTaxType;
        if (result.tax_type_value.toLowerCase().startsWith ("update"))
        {
           
             newTaxType=result.tax_type_value.slice(7,);
             console.log("inside main final if condition",newTaxType);
        }
        else
        {
            newTaxType=result.tax_type_value;
        }
         
         var shortDesc="I want to update my " +`${newTaxType}`+" data" + " following are details:-"+"entityId : "+`${result.entityID}`+",New "+`${newTaxType}`+" data"+":"+`${result.taxDetails}`;
         var json={
            "action": "create_ops_ticket",
            "state": "1",
             "call_code": "ContactOne bot",
             "assignment_group": "assignment group",
             "priority": 4,
             "category": "inquiry",
            "short_description":shortDesc,
            "request_id":requestId,
            "reason": 1            
        }
        
    }
   else if(result.intent=='Entity_finance') {
        var  newFinanceType;
        if (result.finance_type_value.toLowerCase().startsWith ("update"))
        {
           
             newFinanceType=result.finance_type_value.slice(7,);
             console.log("inside main final if condition",newTaxType);
        }
        else
        {
            newFinanceType=result.finance_type_value;
        }
         
         var shortDesc="I want to update my " +`${newFinanceType}`+" data" + " following are details:-"+"entityId : "+`${result.entityID}`+",New "+`${newFinanceType}`+" details"+":"+`${result.financeDetails}`;
         var json={
            "action": "create_ops_ticket",
            "state": "1",
             "call_code": "ContactOne bot",
             "assignment_group": "assignment group",
             "priority": 4,
             "category": "inquiry",
            "short_description":shortDesc,
            "request_id":requestId,
            "reason": 1           
        }
        
   }else if(result.intent=='Workflow_queries'){
                 
         var shortDesc="I am having issue on workflow following are details:-"+"entityId : "+`${result.entityID}`+",Workflow issue type :"+`${result.workflow_type_value}`+" ,workflow issue description"+":"+`${result.workflowDetails_value}`;
         var json={
            "action": "create_ops_ticket",
            "state": "1",
             "call_code": "ContactOne bot",
             "assignment_group": "assignment group",
             "priority": 4,
             "category": "inquiry",
            "short_description":shortDesc,
            "request_id":requestId,
            "reason": 1           
        }
       
   }
   else if(result.intent=='EntityEditorsUpdate'){
      var shortDesc="I want to update my " +`${result.editorType_value}` + " following are details:-"+"entityId : "+`${result.entityID}`+",New "+`${result.editorType_value}`+" details"+":"+`${result.editorName_value}`;
         var json={
            "action": "create_ops_ticket",
            "state": "1",
             "call_code": "ContactOne bot",
             "assignment_group": "assignment group",
             "priority": 4,
             "category": "inquiry",
            "short_description":shortDesc,
            "request_id":requestId,
            "reason": 1            
        }
   }
      else if(result.intent=='Entity_CMS'){
      var shortDesc="I want to know my CMS number of "+"entityId : "+`${result.entityID}`;
         var json={
            "action": "create_ops_ticket",
            "state": "1",
             "call_code": "ContactOne bot",
             "assignment_group": "assignment group",
             "priority": 4,
             "category": "inquiry",
            "short_description":shortDesc,
            "request_id":requestId,
            "reason": 1            
        }
   } 
       var json1=JSON.stringify(json);
       
       
        await stepContext.context.sendActivity(json1);
        //  await stepContext.context.sendActivity(msg);
        // const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
        // await timeout(3000);
        // var reply = MessageFactory.suggestedActions(['Yes', 'No'], 'Is there anything else I can help you with?');
        //           await stepContext.context.sendActivity(reply);
    }
    
    
     else {
         
         var json={
                        
                             "action": "handover"
                   }
                    var json1=JSON.stringify(json);
         console.log("in else part of finalStep Mian js",stepContext);
         await stepContext.context.sendActivity(json1);
       
    }
    return await stepContext.endDialog();
}
}

module.exports.MainDialog = MainDialog;