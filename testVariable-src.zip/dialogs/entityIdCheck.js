// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const {ActivityTypes,MessageFactory,TurnContext} = require('botbuilder');
const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const { ConfirmPrompt, TextPrompt,NumberPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
// const { DateResolverDialog } = require('./dateResolverDialog');
const { CardFactory } = require('botbuilder-core');
const AddressTypes = require('./AdaptiveCards/AddressTypes.json');
const finance_card = require('./AdaptiveCards/financeData.json');
const CONFIRM_PROMPT = 'confirmPrompt';
// const DATE_RESOLVER_DIALOG = 'dateResolverDialog';
const TEXT_PROMPT = 'textPrompt';
const WATERFALL_DIALOG = 'waterfallDialog';
const NUMBER_PROMPT='numberprompt';
class entityIdCheck extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'entityIdCheck');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(NUMBER_PROMPT))            
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [               
				this.EntityID.bind(this),
                this.EntityID1.bind(this)
                  
				
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

    /**
     * If a destination city has not been provided, prompt for one.
     */
    async EntityID(stepContext) {
        const bookingDetails = stepContext.options;
        console.log("Intent namein check file+++++++ is: ", bookingDetails);        
        if (bookingDetails.toString().length != 8) {
            console.log("BEFORE card entiy IDDDDDDQQQ",bookingDetails);        
            return await stepContext.prompt('textPrompt', "yes");
            console.log("Check entiy IDDDDDDQQQ",typeof((stepContext.context.activity.text).length));           
        }
        else
        {
             return await stepContext.next();
        }
    }
      async EntityID1(stepContext){
          console.log("ENTITYID1");
          if((stepContext.context.activity.text).length==8)
          {   
               console.log("indise of if condition IN CHECK FILE");
                return await stepContext.endDialog(stepContext.context.activity.text);               
          }
        else if((stepContext.context.activity.text).length!=8)
        {
            return await stepContext.prompt('textPrompt', "Oops sorry, Looks like I am not able to help you this time");
        }
      return await stepContext.next();
      }     
        
}

module.exports.entityIdCheck = entityIdCheck;