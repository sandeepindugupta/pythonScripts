// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { InputHints, MessageFactory,ActivityTypes,TurnContext } = require('botbuilder');
const { NumberPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
// const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');

const NUMBER_PROMPT='numberprompt';
const WATERFALL_DIALOG = 'waterfallDialog';

class workflowEntityCheck extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'workflowEntityCheck');
        this.addDialog(new NumberPrompt(NUMBER_PROMPT, this.EntityLengthCheck.bind(this)))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [
                this.initialStep.bind(this),
                this.finalStep.bind(this)
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }
    

    async initialStep(stepContext) {
        
        const entity_id = stepContext.options;
        console.log("entity in initial step of check",entity_id.entity_id_value);
        console.log("entityid value ",entity_id);
        

        const promptMessage=MessageFactory.suggestedActions(['Cancel'],"I can help you in resolving workflow issue on legal entity.\nWhat is the **8 digit Legal Entity Directory ID**?")
        const repromptMessage = MessageFactory.suggestedActions(['Cancel'], "Sorry,that doesn't look right.Please provide the **8 digit Entity Directory ID (Swiss Re ID)**");
               
        if (!entity_id.entity_id_value ) {
            console.log("123entity id check");
            return await stepContext.prompt(NUMBER_PROMPT,
                {
                    prompt: promptMessage,
                    retryPrompt: repromptMessage
                });
        }       
        if (entity_id.length!=8) { 
            
            
            console.log("checking reprompt");
            // This is essentially a "reprompt" of the data we were given up front.
            return await stepContext.prompt(NUMBER_PROMPT, { prompt: repromptMessage });
          
        }
        console.log("else condition of entity check");     
        return await stepContext.next(entity_id);
    }

    async finalStep(stepContext) {
        const entity_id = stepContext.result; 
        console.log("entity id in entity check",entity_id); 

        return await stepContext.endDialog(entity_id);
    }

    async EntityLengthCheck(promptContext) {
     
          if (promptContext.recognized.succeeded) {
         if ((promptContext.recognized.value).toString().length == 8 ) {        
            return true;         
        }
        }
        return false;
    }
}

module.exports.workflowEntityCheck = workflowEntityCheck;
