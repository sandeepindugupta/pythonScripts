// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const {NumberPrompt,ConfirmPrompt, TextPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
const { CardFactory } = require('botbuilder-core');
const editorList=require("./AdaptiveCards/EditorList.json");
const CONFIRM_PROMPT = 'confirmPrompt';
const { Entity_ID_check } = require('./Entity_ID_check');
const TEXT_PROMPT = 'textPrompt';
const NUMBER_PROMPT='numberprompt';
const ENTITYIDCHECK = 'Entity_ID_check';
const WATERFALL_DIALOG = 'waterfallDialog';

class EntityEditorsUpdate extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'EntityEditorsUpdate');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(NUMBER_PROMPT))
            .addDialog(new Entity_ID_check(ENTITYIDCHECK))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [               
				this.EntityID.bind(this),
                 this.editorType.bind(this),
                this.editorDetails.bind(this),               
                this.confirmStep.bind(this),
                this.finalStep.bind(this),         
				
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

   
   
   
 async EntityID(stepContext) {
        const bookingDetails = stepContext.options;
         const Intent_ent_json = { "intent_value" : "Entity Responsible",
            "entity_id_value":  bookingDetails.entity_id_value
            
        }
        console.log("sdfsdf", bookingDetails.entity_id_value);
         if (!bookingDetails.entity_id_value || (bookingDetails.entity_id_value).length != 8) {
             console.log("entity fucntion");
            return await stepContext.beginDialog("Entity_ID_check", Intent_ent_json);
         }
         else
         {
             return await stepContext.next(bookingDetails.entity_id_value);
         }
 }


    
    async editorType(stepContext) {
        const bookingDetails = stepContext.options;

        bookingDetails.entityID = stepContext.result;
        if (!bookingDetails.editorType) {
              const editorlst = CardFactory.adaptiveCard(editorList);
          await stepContext.context.sendActivity({attachments: [editorlst] });
           return await stepContext.prompt('textPrompt', '');
        } else {
            return await stepContext.next(bookingDetails.editorType_value);
        }
    }
    
    async editorDetails(stepContext) {
        const bookingDetails = stepContext.options;

        bookingDetails.editorType_value = stepContext.result;
        if (!bookingDetails.editorName) {
            return await stepContext.prompt(TEXT_PROMPT, { prompt: 'Please mention the respective editor to be updated: ' });
        } else {
            return await stepContext.next(bookingDetails.editorName_value);
            
        }
    }
    async confirmStep(stepContext) {
        const bookingDetails = stepContext.options;

        bookingDetails.editorName_value = stepContext.result;
        
        
        const Text = [
                     ];

const card = CardFactory.heroCard('', undefined,
            Text, { text: "Thanks, this is what you'hv told me:\n\n**Update a listed editor or responsible on an entity**\n\n**Entity ID** \t\t: "+ bookingDetails.entityID +"\n\n**New** " +`**${bookingDetails.editorType_value}**` + ':\t\t'+ bookingDetails.editorName_value + '\n\n **Do you want to submit this request?**' + ''  });

console.log("Entity responsible step context%%%",stepContext.options);
return await stepContext.prompt(CONFIRM_PROMPT, { prompt: { attachments: [card] } });

        
        
        
          
    }
    

    
    async finalStep(stepContext) {
        console.log("final step is : ",stepContext.result);
        if (stepContext.result === true) {
            const bookingDetails = stepContext.options;

            return await stepContext.endDialog(bookingDetails);
        } else {
            return await stepContext.endDialog();
        }
    }
}

module.exports.EntityEditorsUpdate = EntityEditorsUpdate;