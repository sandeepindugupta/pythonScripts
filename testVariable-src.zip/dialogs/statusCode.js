// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const {ActivityTypes,MessageFactory,TurnContext} = require('botbuilder');
const { ChoicePrompt, ListStyle,ConfirmPrompt, TextPrompt,NumberPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');

const { CardFactory } = require('botbuilder-core');
const AddressTypes = require('./AdaptiveCards/AddressTypes.json');
const CONFIRM_PROMPT = 'confirmPrompt';
const TEXT_PROMPT = 'textPrompt';

const WATERFALL_DIALOG = 'waterfallDialog';
const NUMBER_PROMPT='numberprompt';
const CHOICE_PROMPT = 'CHOICE_PROMPT';
class statusCode extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'statusCode');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(NUMBER_PROMPT))
           
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [               
				this.statusCheck.bind(this),
                 this.statusHandover.bind(this),
                       
				
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

    
    
    async statusCheck(stepContext) {
         
         const status_check_json = JSON.parse(stepContext.context.activity.text);
         console.log("first check",status_check_json.code);
         if(status_check_json.code ==200)
         {
             console.log("second insert");
            const ticket=status_check_json.ticket_id;
            console.log("ticket check",ticket);
         
              const Text = [                          
                     ];
            const card = CardFactory.heroCard('', undefined,
            Text, { text: "Do you want to show "+ticket +" ticket details"});      
          
            return await stepContext.prompt(CONFIRM_PROMPT, {prompt: { attachments: [card] } });
          }else if(status_check_json.code ==401){
             var  code_401={
                                "code": 401, 		
                                "message": "Missing field information",
                                "request_id": status_check_json.request_id,
                                "reason": 3
                                }
      var code401=JSON.stringify(code_401);
      return stepContext.context.sendActivity(code401);
              
          }
          else if(status_check_json.code ==503){
              var code_503={
                            "code": 503,	
                            "message": "origin bot is unavailable",
                            "request_id": status_check_json.request_id,
                            "reason": 3
                            }
              var code503=JSON.stringify(code_503);
              return stepContext.context.sendActivity(code503);
          }
          
         else
         {
             return false;
         }
        
    }
    
    
    
    async statusHandover(stepContext) {
        
        const bookingDetails = stepContext.options;
        const status_handover_json = JSON.parse(stepContext.options);        
        var status = stepContext.result;  
        if (status == true) 
       
        {
              var json= {
                            "action": "handover",
                            "bot": "yada", 
                            "message": "display details on ticket " + status_handover_json.ticket_id,
                             "request_id" : status_handover_json.request_id,
                             "reason": 1
                            
                        }
          var json1=JSON.stringify(json);
         return stepContext.context.sendActivity(json1);  
    
         }            
         else 
         {
           
                 var no_handover = { 
                  "action": "handover",
                  "request_id": status_handover_json.request_id,
                  "reason": 1 
                }
          var cancel_handover1=JSON.stringify(cancel_handover);
          return stepContext.context.sendActivity(cancel_handover1);  
         }        
    }
    
 
    
   
 
    
    /**
     * Complete the interaction and end the dialog.
     */
    //  async finalStep(stepContext) {
    //     if (stepContext.result === true) {
    //         const bookingDetails = stepContext.options;
    //         console.log("inside final step of address ",bookingDetails);
    //         return await stepContext.endDialog(bookingDetails);
    //     }
    //     return await stepContext.endDialog();
    // }
    
}

module.exports.statusCode = statusCode;