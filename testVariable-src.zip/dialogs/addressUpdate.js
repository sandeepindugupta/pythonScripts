// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const {ActivityTypes,MessageFactory,TurnContext} = require('botbuilder');
const { ChoicePrompt, ListStyle,ConfirmPrompt, TextPrompt,NumberPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
const { Entity_ID_check } = require('./Entity_ID_check');

const { CardFactory } = require('botbuilder-core');
const AddressTypes = require('./AdaptiveCards/AddressTypes.json');
const CONFIRM_PROMPT = 'confirmPrompt';
const TEXT_PROMPT = 'textPrompt';
const ENTITYIDCHECK = 'Entity_ID_check';
const WATERFALL_DIALOG = 'waterfallDialog';
const NUMBER_PROMPT='numberprompt';
const CHOICE_PROMPT = 'CHOICE_PROMPT';
class addressUpdate extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'addressUpdate');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(NUMBER_PROMPT))
            .addDialog(new Entity_ID_check(ENTITYIDCHECK))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [               
				this.EntityID.bind(this),
                 this.addressType.bind(this),
                this.address.bind(this),               
                this.confirmStep.bind(this),  
                this.finalStep.bind(this)       
				
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

   
    
    async EntityID(stepContext) {
        const bookingDetails = stepContext.options;
        
        const Intent_ent_json = { "intent_value" : "address data",
            "entity_id_value":  bookingDetails.entity_id_value
            
        }
        
        
        console.log("complete value", bookingDetails.intent);
        console.log("sdfsdf", bookingDetails.entity_id_value);
         if (!bookingDetails.entity_id_value || (bookingDetails.entity_id_value).length != 8) {
             console.log("entity fucntion");
            return await stepContext.beginDialog("Entity_ID_check", Intent_ent_json);
            
         }
         else
         {
             return await stepContext.next(bookingDetails.entity_id_value);
         }
        
    }
    
    
    
    async addressType(stepContext) {
        
        const bookingDetails = stepContext.options;     
        
        if(stepContext.result.toString().length != 8)
            {
                console.log("ending the dialog");               
                return await stepContext.endDialog();
            }
        // Capture the response to the previous step's prompt
        bookingDetails.entityID = stepContext.result;           
     
        if (!bookingDetails.addressType) 
       
            {
               const Address_Types1 = CardFactory.adaptiveCard(AddressTypes);
               await stepContext.context.sendActivity({attachments: [Address_Types1] });
               return await stepContext.prompt('textPrompt', '');        

            }
            
        else {
              console.log("address type is given");
            return await stepContext.next(bookingDetails.address_type_value);
        }        
    }
    
 
    
    async address(stepContext) {
        const bookingDetails = stepContext.options;
        console.log("options ##",stepContext);
 console.log("after entity id check123");
        
     
        
        bookingDetails.address_type_value = stepContext.result.toLowerCase();      
        var  newAddressType;
        if (bookingDetails.address_type_value.startsWith ("update"))
        {
            console.log("newAddressType", stepContext.result.toLowerCase());
             newAddressType=bookingDetails.address_type_value.slice(7,);
        }
        else
        {
            newAddressType=bookingDetails.address_type_value;
        }
        console.log("stepContext.result in address$$",stepContext.result);
        if (!bookingDetails.address) 
        {
             return await stepContext.prompt(TEXT_PROMPT, { prompt: 'What’s the correct ' + `**${newAddressType}**`+ "?\nPlease type or paste it in full." });
        } 
        else 
        {            
            return await stepContext.next(bookingDetails.address_value);            
        }
    }
    async confirmStep(stepContext) {        
        const bookingDetails = stepContext.options;
        // Capture the results of the previous step
        bookingDetails.address = stepContext.result;
          var  newAddressType;
        if (bookingDetails.address_type_value.toLowerCase().startsWith ("update"))
        {
            console.log("newAddressType", stepContext.result.toLowerCase());
             newAddressType=bookingDetails.address_type_value.slice(7,);
        }
        else
        {
            newAddressType=bookingDetails.address_type_value;
        }
        
        const Text = [
                     ];
                     

// const card = CardFactory.heroCard('', undefined,
//             Text, { text: "Thanks, this is what you’hv told me:\n\n**Updated address data**\n\n**Entity ID** \t\t: "+ bookingDetails.entityID +'\n\n **New**\t'+`**${newAddressType}**` +':\t\t'+ bookingDetails.address +'\n\n **Do you want to submit this request?**\n'});
             
             
   console.log("address update step context$$",stepContext.options); 
          // await stepContext.prompt(CONFIRM_PROMPT,{prompt: { attachments: [card] }});
           // await stepContext.prompt('textPrompt', '')
          await stepContext.context.sendActivity("Thanks, this is what you’hv told me:\n\n**Updated address data**\n\n**Entity ID** \t\t: "+ bookingDetails.entityID +'\n\n **New**\t'+`**${newAddressType}**` +":\t\t"+ bookingDetails.address)
        //    var action=  MessageFactory.suggestedActions(['Yes','No'], "submit");
        //  return await stepContext.prompt(TEXT_PROMPT,action);
        //  return await stepContext.context.sendActivity(action);
        const card = CardFactory.heroCard('', undefined,
            Text, { text: "**Do you want to submit this request?**"});
 return await stepContext.prompt(CONFIRM_PROMPT, {prompt: { attachments: [card] } });
        
    }
    
   
     async finalStep(stepContext) {
        if (stepContext.result === true) {
            const bookingDetails = stepContext.options;
            console.log("inside final step of address ",bookingDetails);
            return await stepContext.endDialog(bookingDetails);
        }
        return await stepContext.endDialog();
    }
    
}

module.exports.addressUpdate = addressUpdate;