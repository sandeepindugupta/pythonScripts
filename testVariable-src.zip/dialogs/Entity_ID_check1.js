// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { InputHints, MessageFactory,ActivityTypes,TurnContext ,ActivityHandler} = require('botbuilder');
const { NumberPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');

const Many = require('extends-classes');
const NUMBER_PROMPT='numberprompt';
const WATERFALL_DIALOG = 'waterfallDialog';
const CONVERSATION_DATA_PROPERTY = 'conversationData';
const USER_PROFILE_PROPERTY = 'userProfile';
// CancelAndHelpDialog
class Entity_ID_check extends Many(ActivityHandler,CancelAndHelpDialog) {
    constructor(id,logger,conversationState, userState) {
        
        super(id || 'Entity_ID_check');
        //  if (!conversationState) throw new Error('[DialogBot]: Missing parameter. conversationState is required');
        // if (!userState) throw new Error('[DialogBot]: Missing parameter. userState is required');
        // if (!dialog) throw new Error('[DialogBot]: Missing parameter. dialog is required');

        
        // this.conversationData = conversationState.createProperty(CONVERSATION_DATA_PROPERTY);
        // this.userProfile = userState.createProperty(USER_PROFILE_PROPERTY);
        // this.conversationState = conversationState;
        // this.userState = userState;
        // this.dialog = dialog;
        // this.dialogState = this.conversationState.createProperty('DialogState'); 
        
       
        this.addDialog(new NumberPrompt(NUMBER_PROMPT, this.EntityLengthCheck.bind(this)))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [
                this.initialStep.bind(this),
                this.finalStep.bind(this)
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
            // this.onMessage(async (context, next) => {
            // console.log('Running dialog with Message Activity.');

            // const userProfile = await this.userProfile.get(context, {});
            // const conversationData = await this.conversationData.get(
            //     context, {});

          // conversationData.test=context.activity;
          // conversationData.san1=context.activity.timestamp;
          // conversationData.count=1;
          // console.log("testing session ",conversationData.test);
          // console.log("testing session11111 ",conversationData.san);
            // Run the Dialog with the new message Activity.
    //         await this.dialog.run(context, this.dialogState);

    //         // By calling next() you ensure that the next BotHandler is run.
    //         await next();
    //     });
    // }
    

    async initialStep(stepContext) {
        // const conversationData = await this.conversationData.get(
        //         context, {});
        // conversationData.count=0;
        const entity_id = stepContext.options;
        console.log("entity in initial step of check",entity_id.entity_id_value);
        console.log("entityid value ",entity_id);
        
       
        
          const promptMessage=MessageFactory.suggestedActions(['Cancel'],"I can help you to request " + entity_id.intent_value +" be updated on legal entity.\nWhat is the **8 digit Legal Entity Directory ID**?")
                 const repromptMessage = MessageFactory.suggestedActions(['Cancel'], "Sorry,that doesn't look right.Please provide the **8 digit Entity Directory ID (Swiss Re ID)**\n\nType Cancel to exit LEM help and talk about something else.");
                
        
        if (!entity_id.entity_id_value ) {
            // We were not given any entity at all so prompt the user.
            console.log("123entity id check");
            return await stepContext.prompt(NUMBER_PROMPT,
                {
                    prompt: promptMessage,
                    retryPrompt: repromptMessage
                });
        }       
        if (entity_id.length!=8) { 
            
            console.log("checking reprompt first condition",entity_id.length);
            // This is essentially a "reprompt" of the data we were given up front.
            return await stepContext.prompt(NUMBER_PROMPT, { prompt: repromptMessage });
            // }
        }
        console.log("else condition of entity check");     
        return await stepContext.next(entity_id);
    }

    async finalStep(stepContext) {
        const entity_id = stepContext.result; 
        console.log("entity id in entity check",entity_id); 
        return await stepContext.endDialog(entity_id);
    }

    async EntityLengthCheck(promptContext) {
     
          if (promptContext.recognized.succeeded) {
         if ((promptContext.recognized.value).toString().length == 8 ) {        
            return true;         
        }
        }
        return false;
    }
}

// module.exports.Entity_ID_check = Entity_ID_check;
