// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

// index.js is used to setup and configure your bot

// Import required pckages
const path = require('path');
const restify = require('restify');
var fs = require('fs');
var http = require('http');
// const Entity_ID_check=require('./dialogs/Entity_ID_check');

// Import required bot services. See https://aka.ms/bot-services to learn more about the different parts of a bot.
const { BotFrameworkAdapter, MemoryStorage, ConversationState, UserState,PrivateConversationState } = require('botbuilder');

// This bot's main dialog.
const { DialogAndWelcomeBot } = require('./bots/dialogAndWelcomeBot');
const { MainDialog } = require('./dialogs/mainDialog');
const { dialogBot } = require('./bots/dialogBot');
const { starmind } = require('./dialogs/starmind');
// Note: Ensure you have a .env file and include LuisAppId, LuisAPIKey and LuisAPIHostName.
const ENV_FILE = path.join(__dirname, '.env');
require('dotenv').config({ path: ENV_FILE });

// Create adapter.
// See https://aka.ms/about-bot-adapter to learn more about adapters.
const adapter = new BotFrameworkAdapter({
    appId: process.env.MicrosoftAppId,
    appPassword: process.env.MicrosoftAppPassword,
    channelService: process.env.ChannelService,
    openIdMetadata: process.env.BotOpenIdMetadata
});








// Catch-all for errors.
adapter.onTurnError = async (context, error) => {
    // This check writes out errors to console log
    // NOTE: In production environment, you should consider logging this to Azure
    //       application insights.
    
    
    console.error(`\n [onTurnError]: ${ error }`);
    // Send a message to the user
    await context.sendActivity(`Oops. Something went wrong!`);
    // Clear out state
    await conversationState.delete(context);
};

// Define a state store for your bot. See https://aka.ms/about-bot-state to learn more about using MemoryStorage.
// A bot requires a state store to persist the dialog and user state between messages.
let conversationState, userState;

// For local development, in-memory storage is used.
// CAUTION: The Memory Storage used here is for local bot debugging only. When the bot
// is restarted, anything stored in memory will be gone.
const memoryStorage = new MemoryStorage();
conversationState = new ConversationState(memoryStorage);
const privateconversationState = new PrivateConversationState(memoryStorage);
userState = new UserState(memoryStorage);
// const dialog1=new Entity_ID_check(logger,conversationState,userState,dialog);
// Pass in a logger to the bot. For this sample, the logger is the console, but alternatives such as Application Insights and Event Hub exist for storing the logs of the bot.
const logger = console;

// Create the main dialog.
const dialog = new MainDialog(logger,privateconversationState);
const star=new starmind(privateconversationState);
const bot = new DialogAndWelcomeBot(privateconversationState,conversationState, userState, dialog, logger);
// const bot = new dialogBot(conversationState, userState, dialog, logger);
// const dialog1san=new Entity_ID_check(logger,conversationState,userState);
// Create HTTP server
let server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3978, function() {
    console.log(`\n${ server.name } listening to ${ server.url }`);
    console.log(`\nGet Bot Framework Emulator: https://aka.ms/botframework-emulator`);
});

// Listen for incoming activities and route them to your bot main dialog.
server.post('/api/messages', (req, res) => {
    // Route received a request to adapter for processing
    adapter.processActivity(req, res, async (turnContext) => {
      
      console.log("Turncontext",turnContext);
      // if(turnContext.activity.type === ActivityTypes.Message) {
      //   if (turnContext.activity.name && turnContext.activity.name === 'inactive') {
      //     console.log("proactive msg");
      //       await turnContext.sendActivity({
      //           text: 'Are you still there?',
      //           name: 'inactive'
      //       });
      //   }
      // } 
        // route to bot activity handler.
        // console.log("inside index",req);
        // console.log("response",turnContext);
        // console.log("turn on context ",turnContext.activity.timestamp,turnContext.activity.type);
        await bot.run(turnContext);
        console.log("Turncontext!!!!!!!!",turnContext);
        // const timeArray=[];
        // timeArray.push(turnContext.activity.timestamp)
        // timeArray.push(turnContext.activity.timestamp)
        // console.log("time array",timeArray);
        
        
    });
});


server.get('/englobe',function(req, resp) { 
   //console.log("ASDASDD");    
  resp.header("Content-Type", "application/json"); 
  resp.header("Access-Control-Allow-Origin", "*"); 
  console.log("hellooooo flow 1"); 
  fs.readFile("Default.html", function (error, pgResp) { 
            if (error) { 
                resp.writeHead(404); 
                resp.write('Contents you are looking are Not Found'); 
            } else { 
                resp.writeHead(200, { 'Content-Type': 'text/html' }); 
                resp.write(pgResp); 
            } 
             
            resp.end(); 
        }); 
  
});
