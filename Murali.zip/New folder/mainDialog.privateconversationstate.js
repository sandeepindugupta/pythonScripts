// // var restify = require('restify');
// // var builder = require('botbuilder');
// // var request = require("request");
// // var botbuilder_azure = require("botbuilder-azure");
// // var https = require('https');
// // var dateTime = require('node-datetime');
// // var pdfjsLib = require('pdfjs-dist');
// // var unzip = require('unzip')
// // var fs = require('fs');
// // var {
// //     AzureSearch
// // } = require('./azure-search.js');

// // var appInsights = require('applicationinsights');
// // appInsights.setup(process.env.BotDevAppInsightsKey)
// //  .setAutoDependencyCorrelation(true)
// //     .setAutoCollectRequests(true)
// //     .setAutoCollectPerformance(true)
// //     .setAutoCollectExceptions(true)
// //     .setAutoCollectDependencies(true)
// //     .setUseDiskRetryCaching(true)
// //     .start();
// // var appInsightsClient = appInsights.defaultClient;

// // const WelcomeCard = require('./cards/welcome.json');
// // const { CardFactory,MessageFactory } = require('botbuilder-core');
// // const { ActivityHandler } = require('botbuilder');
// // const {
// //     TimexProperty
// // } = require('@microsoft/recognizers-text-data-types-timex-expression');
// // const {
// //     ComponentDialog,
// //     DialogSet,
// //     DialogTurnStatus,
// //     TextPrompt,
// //     WaterfallDialog
// // } = require('botbuilder-dialogs');
// // // const {
// // //     BookingDialog
// // // } = require('./bookingDialog');
// // // const {
// // //     LuisHelper
// // // } = require('./luisHelper');
// // const {
// //     QnA
// // } = require('./create-new-knowledge-base');
// // const MAIN_WATERFALL_DIALOG = 'mainWaterfallDialog';
// // const AZURESEARCH = 'AzureSearch';
// // //const BOOKING_DIALOG = 'bookingDialog';
// // //const {Azsearch} = require('./azure-search');

// // class MainDialog extends ComponentDialog {
// //     constructor(logger) {
// //         super('MainDialog');

// //         if (!logger) {
// //             logger = console;
// //             logger.log('[MainDialog]: logger not passed in, defaulting to console');
// //         }

// //         this.logger = logger;

// //         // Define the main dialog and its related components.
// //         // This is a sample "book a flight" dialog.
// //         this.addDialog(new TextPrompt('TextPrompt'))
// //             .addDialog(new AzureSearch(AZURESEARCH))
// //             .addDialog(new WaterfallDialog(MAIN_WATERFALL_DIALOG, [
// //                 this.introStep.bind(this),
// //                 // this.actStep.bind(this),
// //                 // this.finalStep.bind(this)
// //             ]));

// //         this.initialDialogId = MAIN_WATERFALL_DIALOG;
// //     }

// //     async run(turnContext, accessor) {
// //         const dialogSet = new DialogSet(accessor);
// //         dialogSet.add(this);

// //         const dialogContext = await dialogSet.createContext(turnContext);
// //         const results = await dialogContext.continueDialog();
// //         if (results.status === DialogTurnStatus.empty) {
// //             await dialogContext.beginDialog(this.id);
// //         }
// //     }

    
// //     async introStep(stepContext) {
// //         var c = String(stepContext.context.activity.text);
// //         var d = c.toLowerCase();
// //         let bookingDetails = {};
        
// //         // stepContext.context.privateConversationData
        
// //          console.log("BEFORE FIRST : ",stepContext.context.activity);
// //          console.log("ppppppppqqqqqrrr",d);
// //         if (!process.env.QnA_EndpointKey || !process.env.QnA_Host || !process.env.QnA_kb_Key) {
// //             await stepContext.context.sendActivity('NOTE: QnA is not configured. To enable all capabilities, add `QnA_EndpointKey`, `QnA_Host` and `QnA_kb_Key` to the .env file.');
// //             //return await stepContext.next();
        
// //         } else if (process.env.QnA_EndpointKey && process.env.QnA_Host && process.env.QnA_kb_Key ) {
            
// //             // return await stepContext.beginDialog('create-new-knowledge-base', stepContext.context);
// //             bookingDetails = await QnA.executeQnAQuery(this.logger, stepContext.context);

           
            
// //             console.log("BEFORE : ",stepContext.context.activity); 
// //             this.logger.log('QnA extracted these booking details:', bookingDetails);
            
           
// //             if(stepContext.context.activity.value)
// //             {
                
// //                 console.log("hyyyyyy",stepContext.context.activity.from.name);
// //                 console.log("whyeeeeeeeee",stepContext.context.activity.conversation.id);
// //                 console.log("piiiiiiiii",stepContext.context.activity.timestamp);
// //                 console.log("assssssssssssssddddddddddff",stepContext.context.activity.text);
// //                 console.log("byeeeeeeeeeeee",stepContext.context.activity.value);
// //                 console.log("zzzzzzz",stepContext.context.activity.value.Query);
// //                 console.log("zzzzzzz",stepContext.context.activity.value.Category);
// //                 console.log("zzzzzzz",stepContext.context.activity.value.Feedback);
                
// //                 appInsightsClient.trackEvent({ name: "Failure_Details", properties: {conversation_Id: stepContext.context.activity.conversation.id, 
// //                                               timestamp: stepContext.context.activity.timestamp,
// //                                                Query :stepContext.context.activity.value.Query,
// //                                                Category:stepContext.context.activity.value.Category,
// //                                                Feedback: stepContext.context.activity.value.Feedback } });
// //                 stepContext.context.sendActivity("Sorry for the inconvenience happened. Thanks for your feedback. You can contact the support link at [XXXX](XXXX) for further assistance.");
// //                 this.stepContext.endDialog();
// //             }
             
          
// //             if (!bookingDetails && d!="yes" && d!= "no") {
                 
// //                 let searchDetails = {};
                
// //                 await stepContext.beginDialog("AzureSearch", stepContext.context);

// //               //  return await stepContext.endDialog();

// //                    }
// //              else if(d =="yes")
// //                    {
                         
// //                       stepContext.context.sendActivity("Thanks.");
// //                       console.log("hmmmhmmmhmmmhmmm");
// //                       const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
// //                    await timeout(100);

// //      const wel = CardFactory.adaptiveCard(WelcomeCard);
// //       await stepContext.context.sendActivity({ attachments: [wel] });
// //       console.log("yuioppoiuyyyy",stepContext.context.activity);
// //       console.log("qwerty",stepContext.context.activity.text);
// //       appInsightsClient.trackEvent({ name: "successEvents", properties: { success: stepContext.context.activity.text, 
// //                                              conversation_Id: stepContext.context.activity.conversation.id, 
// //                                               timestamp: stepContext.context.activity.timestamp
// //                                                 } });
      
// //    }
// //              else if(d == "no")
// //                    {
// //                       var card3 = 
// //                        {
// //                         "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
// //                         "type": "AdaptiveCard",
// //                         "version": "1.0",
// //                         "body": [
// //                           {
// //                             "type": "TextBlock",
// //                             "text": "",
// //                             "size": "large",
// //                             "weight": "bolder"
// //                           },
// //                           {
// //                             "type": "Input.Text",
// //                             "placeholder": "Please rephrase your query here",
// //                             "style": "text",
// //                             "isMultiline": true,
// //                             "maxLength": 0,
// //                             "id": "Query"
// //                           },
// //                           {
// //                             "type": "Input.ChoiceSet",
// //                             "id": "Category",
// //                             "style": "compact",
// //                             "placeholder": "Select the category of query.",
// //                             "choices": [
// //                               {
// //                                 "title": "Functional",
// //                                 "value": "Functional"
// //                               },
// //                               {
// //                                 "title": "Trouble Shooting",
// //                                 "value": "Trouble Shooting"
// //                               },
// //                               {
// //                                 "title": "Training",
// //                                 "value": "Training"
// //                               }
// //                             ]
// //                           },
// //                              {
// //                             "type": "Input.Text",
// //                             "placeholder": "Please enter your feedback here",
// //                             "style": "text",
// //                             "isMultiline": true,
// //                             "maxLength": 0,
// //                             "id": "Feedback"
// //                           }
// //                         ],
// //                         "actions": [
// //                           {
// //                             "type": "Action.Submit",
// //                             "title": "Submit",
// //                             "data": {
// //                               "x": "Submit"
// //                             }
// //                           }
// //                         ]
// //                       };

// //                 console.log("mmmmmmmmmmmmmmmm",stepContext.context.activity);       
                
                
// //                 const welcomeCard1 = CardFactory.adaptiveCard(card3);
// //                 await stepContext.context.sendActivity({ attachments: [welcomeCard1] });     
            
           
// //     //console.log("llllllllllllllllllllllllllll");
    
                   
// //         }
      
// //       // console.log("llllllllllllllllllllllllllll",stepContext.context.activity);
// //         }

// // //console.log("lllllllllllll22222222222",stepContext.context.activity);
// //     }
// // }

// //     module.exports.MainDialog = MainDialog;


// var restify = require('restify');
// var builder = require('botbuilder');
// var request = require("request");
// var botbuilder_azure = require("botbuilder-azure");
// var https = require('https');
// var dateTime = require('node-datetime');
// var pdfjsLib = require('pdfjs-dist');
// var unzip = require('unzip')
// var fs = require('fs');
// //var {
// //     AzureSearch
// // } = require('./azure-search.js');

// var appInsights = require('applicationinsights');
// appInsights.setup(process.env.BotDevAppInsightsKey)
//  .setAutoDependencyCorrelation(true)
//     .setAutoCollectRequests(true)
//     .setAutoCollectPerformance(true)
//     .setAutoCollectExceptions(true)
//     .setAutoCollectDependencies(true)
//     .setUseDiskRetryCaching(true)
//     .start();
// var appInsightsClient = appInsights.defaultClient;

// const WelcomeCard = require('./cards/welcome.json');
// const { CardFactory,MessageFactory } = require('botbuilder-core');
// const { ActivityHandler } = require('botbuilder');
// const {
//     TimexProperty
// } = require('@microsoft/recognizers-text-data-types-timex-expression');
// const {
//     ComponentDialog,
//     DialogSet,
//     DialogTurnStatus,
//     TextPrompt,
//     WaterfallDialog
// } = require('botbuilder-dialogs');
// // const {
// //     BookingDialog
// // } = require('./bookingDialog');
// // const {
// //     LuisHelper
// // } = require('./luisHelper');
// const {
//     QnA
// } = require('./create-new-knowledge-base');
// const MAIN_WATERFALL_DIALOG = 'mainWaterfallDialog';
// const AZURESEARCH = 'AzureSearch';
// //const BOOKING_DIALOG = 'bookingDialog';
// const {AzureSearch} = require('./azure-search');

// class MainDialog extends ComponentDialog {
//     constructor(logger) {
//         super('MainDialog');

//         if (!logger) {
//             logger = console;
//             logger.log('[MainDialog]: logger not passed in, defaulting to console');
//         }

//         this.logger = logger;

//         // Define the main dialog and its related components.
//         // This is a sample "book a flight" dialog.
//         this.addDialog(new TextPrompt('TextPrompt'))
//            // .addDialog(new AzureSearch(AZURESEARCH))
//             .addDialog(new WaterfallDialog(MAIN_WATERFALL_DIALOG, [
//                 this.introStep.bind(this),
//                 // this.actStep.bind(this),
//                 // this.finalStep.bind(this)
//             ]));

//         this.initialDialogId = MAIN_WATERFALL_DIALOG;
//     }

//     async run(turnContext, accessor) {
//         const dialogSet = new DialogSet(accessor);
//         dialogSet.add(this);

//         const dialogContext = await dialogSet.createContext(turnContext);
//         const results = await dialogContext.continueDialog();
//         if (results.status === DialogTurnStatus.empty) {
//             await dialogContext.beginDialog(this.id);
//         }
//     }

    
//     async introStep(stepContext) {
//         var c = String(stepContext.context.activity.text);
//         var d = c.toLowerCase();
//         let bookingDetails = {};
//         let x = {};
        
//         // stepContext.context.privateConversationData
        
//          console.log("BEFORE FIRST : ",stepContext.context.activity);
//          console.log("ppppppppqqqqqrrr",d);
//         if (!process.env.QnA_EndpointKey || !process.env.QnA_Host || !process.env.QnA_kb_Key) {
//             await stepContext.context.sendActivity('NOTE: QnA is not configured. To enable all capabilities, add `QnA_EndpointKey`, `QnA_Host` and `QnA_kb_Key` to the .env file.');
//             //return await stepContext.next();
        
//         } else if (process.env.QnA_EndpointKey && process.env.QnA_Host && process.env.QnA_kb_Key ) {
            
//             // return await stepContext.beginDialog('create-new-knowledge-base', stepContext.context);
//             bookingDetails = await QnA.executeQnAQuery(this.logger, stepContext.context);

           
            
//             console.log("BEFORE : ",stepContext.context.activity); 
//             this.logger.log('QnA extracted these booking details:', bookingDetails);
            
           
//             if(stepContext.context.activity.value)
//             {
                
//                 console.log("hyyyyyy",stepContext.context.activity.from.name);
//                 console.log("whyeeeeeeeee",stepContext.context.activity.conversation.id);
//                 console.log("piiiiiiiii",stepContext.context.activity.timestamp);
//                 console.log("assssssssssssssddddddddddff",stepContext.context.activity.text);
//                 console.log("byeeeeeeeeeeee",stepContext.context.activity.value);
//                 console.log("zzzzzzz",stepContext.context.activity.value.Query);
//                 console.log("zzzzzzz",stepContext.context.activity.value.Category);
//                 console.log("zzzzzzz",stepContext.context.activity.value.Feedback);
//                 //var xxxx = https://dev53970.service-now.com/sp?id=ticket&table=incident&sys_id=3ad52d83379733003dcbd02783990e4f;
                
//                 appInsightsClient.trackEvent({ name: "Failure_Details", properties: {conversation_Id: stepContext.context.activity.conversation.id, 
//                                               timestamp: stepContext.context.activity.timestamp,
//                                                Query :stepContext.context.activity.value.Query,
//                                                Category:stepContext.context.activity.value.Category,
//                                                Feedback: stepContext.context.activity.value.Feedback } });
//                 stepContext.context.sendActivity("Sorry for this inconvenience. Thanks for your feedback. For further assistance please click the support link [https://dev53970.service-now.com/sp?id=index](https://dev53970.service-now.com/sp?id=index)");
//                 this.stepContext.endDialog();
//             }
             
          
//             if (!bookingDetails && d!="yes" && d!= "no") {
//                 appInsightsClient.trackEvent({ name: "EveryEvent", properties: { input: stepContext.context.activity.text, 
//                                              conversation_Id: stepContext.context.activity.conversation.id, 
//                                               timestamp: stepContext.context.activity.timestamp
//                                                 } });
                 
//                // let searchDetails = {};
//                 x = await AzureSearch.RecommededName(stepContext.context);
                
//               var y = stepContext.context.activity;
            
//             console.log("BEFORE : ",stepContext.context.activity); 
//             console.log("searchhhhh:",stepContext.context);
//             console.log("hellhell", stepContext.context._respondedRef.responded);
//             //this.logger.log('search extracted these booking details:',x);
//             var xr = String(stepContext.context._respondedRef.responded);
//             console.log("ppppooyyyyrr",xr);
//                 if(xr == "false")
//                 {
//                   console.log("8888888888888888");  
//                   stepContext.context.sendActivity("Sorry! I couldn't understand the question. Please type a valid query.");
//                       console.log("hmmmhmmmhmmmhmmm");
//                       const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
//                    await timeout(300);
//                   const wel = CardFactory.adaptiveCard(WelcomeCard);
//       await stepContext.context.sendActivity({ attachments: [wel] });
//                 }
//                 else if(xr == "true")
//                 {
//                     var card45 ={
// "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
// "type": "AdaptiveCard",
// "version": "1.0",
// "body": [
// {
// "type": "TextBlock",
// "text": "Are you satisfied with the answer?",
// "size": "Large",
// //"weight": "Bolder"
// }
// ],
// "actions": [
// {
// "type": "Action.Submit",
// "title": "Yes",
// "data": "Yes"
// },
// {
// "type": "Action.Submit",
// "title": "No",
// "data": "No"
// }
// ]
// };
//                     console.log("qqqqqqqqqq");
                    
 
//  const wce = CardFactory.adaptiveCard(card45);
//                  await stepContext.context.sendActivity({ attachments: [wce] });
//                  console.log("qwerty");
//                 }}
//                 //await stepContext.beginDialog("AzureSearch", stepContext.context);

//               //  return await stepContext.endDialog();

                     
//              else if(d =="yes")
//                    {
                       
                         
//                       stepContext.context.sendActivity("Thanks.");
//                       console.log("hmmmhmmmhmmmhmmm");
//                       const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
//                    await timeout(300);

//      const wel = CardFactory.adaptiveCard(WelcomeCard);
//       await stepContext.context.sendActivity({ attachments: [wel] });
//       console.log("yuioppoiuyyyy",stepContext.context.activity);
//       console.log("qwerty",stepContext.context.activity.text);
//       appInsightsClient.trackEvent({ name: "successEvents", properties: { success: stepContext.context.activity.text, 
//                                              conversation_Id: stepContext.context.activity.conversation.id, 
//                                               timestamp: stepContext.context.activity.timestamp
//                                                 } });
      
//    }
//              else if(d == "no")
//                    {
//                       var card3 = 
//                        {
//                         "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
//                         "type": "AdaptiveCard",
//                         "version": "1.0",
//                         "body": [
//                           {
//                             "type": "TextBlock",
//                             "text": "",
//                             "size": "large",
//                             "weight": "bolder"
//                           },
//                           {
//                             "type": "Input.Text",
//                             "placeholder": "Please rephrase your query here",
//                             "style": "text",
//                             "isMultiline": true,
//                             "maxLength": 0,
//                             "id": "Query"
//                           },
//                           {
//                             "type": "Input.ChoiceSet",
//                             "id": "Category",
//                             "style": "compact",
//                             "placeholder": "Select the category of query.",
//                             "choices": [
//                               {
//                                 "title": "Functional",
//                                 "value": "Functional"
//                               },
//                               {
//                                 "title": "Trouble Shooting",
//                                 "value": "Trouble Shooting"
//                               },
//                               {
//                                 "title": "Training",
//                                 "value": "Training"
//                               }
//                             ]
//                           },
//                              {
//                             "type": "Input.Text",
//                             "placeholder": "Please enter your feedback here",
//                             "style": "text",
//                             "isMultiline": true,
//                             "maxLength": 0,
//                             "id": "Feedback"
//                           }
//                         ],
//                         "actions": [
//                           {
//                             "type": "Action.Submit",
//                             "title": "Submit",
//                             "data": {
//                               "x": "Submit"
//                             }
//                           }
//                         ]
//                       };

//                 console.log("mmmmmmmmmmmmmmmm",stepContext.context.activity);       
                
                
//                 const welcomeCard1 = CardFactory.adaptiveCard(card3);
//                 await stepContext.context.sendActivity({ attachments: [welcomeCard1] });     
            
           
//     //console.log("llllllllllllllllllllllllllll");
    
                   
//         }
      
//       // console.log("llllllllllllllllllllllllllll",stepContext.context.activity);
//         }

// //console.log("lllllllllllll22222222222",stepContext.context.activity);
//     }
// }

//     module.exports.MainDialog = MainDialog;






// var restify = require('restify');
// var builder = require('botbuilder');
// var request = require("request");
// var botbuilder_azure = require("botbuilder-azure");
// var https = require('https');
// var dateTime = require('node-datetime');
// var pdfjsLib = require('pdfjs-dist');
// var unzip = require('unzip')
// var fs = require('fs');
// var {
//     AzureSearch
// } = require('./azure-search.js');

// var appInsights = require('applicationinsights');
// appInsights.setup(process.env.BotDevAppInsightsKey)
//  .setAutoDependencyCorrelation(true)
//     .setAutoCollectRequests(true)
//     .setAutoCollectPerformance(true)
//     .setAutoCollectExceptions(true)
//     .setAutoCollectDependencies(true)
//     .setUseDiskRetryCaching(true)
//     .start();
// var appInsightsClient = appInsights.defaultClient;

// const WelcomeCard = require('./cards/welcome.json');
// const { CardFactory,MessageFactory } = require('botbuilder-core');
// const { ActivityHandler } = require('botbuilder');
// const {
//     TimexProperty
// } = require('@microsoft/recognizers-text-data-types-timex-expression');
// const {
//     ComponentDialog,
//     DialogSet,
//     DialogTurnStatus,
//     TextPrompt,
//     WaterfallDialog
// } = require('botbuilder-dialogs');
// // const {
// //     BookingDialog
// // } = require('./bookingDialog');
// // const {
// //     LuisHelper
// // } = require('./luisHelper');
// const {
//     QnA
// } = require('./create-new-knowledge-base');
// const MAIN_WATERFALL_DIALOG = 'mainWaterfallDialog';
// const AZURESEARCH = 'AzureSearch';
// //const BOOKING_DIALOG = 'bookingDialog';
// //const {Azsearch} = require('./azure-search');

// class MainDialog extends ComponentDialog {
//     constructor(logger) {
//         super('MainDialog');

//         if (!logger) {
//             logger = console;
//             logger.log('[MainDialog]: logger not passed in, defaulting to console');
//         }

//         this.logger = logger;

//         // Define the main dialog and its related components.
//         // This is a sample "book a flight" dialog.
//         this.addDialog(new TextPrompt('TextPrompt'))
//             .addDialog(new AzureSearch(AZURESEARCH))
//             .addDialog(new WaterfallDialog(MAIN_WATERFALL_DIALOG, [
//                 this.introStep.bind(this),
//                 // this.actStep.bind(this),
//                 // this.finalStep.bind(this)
//             ]));

//         this.initialDialogId = MAIN_WATERFALL_DIALOG;
//     }

//     async run(turnContext, accessor) {
//         const dialogSet = new DialogSet(accessor);
//         dialogSet.add(this);

//         const dialogContext = await dialogSet.createContext(turnContext);
//         const results = await dialogContext.continueDialog();
//         if (results.status === DialogTurnStatus.empty) {
//             await dialogContext.beginDialog(this.id);
//         }
//     }


//     async introStep(stepContext) {
//         var c = String(stepContext.context.activity.text);
//         var d = c.toLowerCase();
//         let bookingDetails = {};

//         // stepContext.context.privateConversationData

//          //console.log("BEFORE FIRST : ",stepContext.context.activity);
//          //console.log("ppppppppqqqqqrrr",d);
//         if (!process.env.QnA_EndpointKey || !process.env.QnA_Host || !process.env.QnA_kb_Key) {
//             await stepContext.context.sendActivity('NOTE: QnA is not configured. To enable all capabilities, add `QnA_EndpointKey`, `QnA_Host` and `QnA_kb_Key` to the .env file.');
//             //return await stepContext.next();

//         } else if (process.env.QnA_EndpointKey && process.env.QnA_Host && process.env.QnA_kb_Key ) {

//             // return await stepContext.beginDialog('create-new-knowledge-base', stepContext.context);
//             bookingDetails = await QnA.executeQnAQuery(this.logger, stepContext.context);


//             //console.log("BEFORE : ",stepContext.context.activity); 
//             this.logger.log('QnA extracted these booking details:', bookingDetails);


//             if(stepContext.context.activity.value)
//             {

//                 //console.log("hyyyyyy",stepContext.context.activity.from.name);
//                 //console.log("whyeeeeeeeee",stepContext.context.activity.conversation.id);
//                 //console.log("piiiiiiiii",stepContext.context.activity.timestamp);
//                 //console.log("assssssssssssssddddddddddff",stepContext.context.activity.text);
//                 //console.log("byeeeeeeeeeeee",stepContext.context.activity.value);
//                 //console.log("zzzzzzz",stepContext.context.activity.value.Query);
//                 //console.log("zzzzzzz",stepContext.context.activity.value.Category);
//                 //console.log("zzzzzzz",stepContext.context.activity.value.Feedback);

//                 appInsightsClient.trackEvent({ name: "Failure_Details", properties: {conversation_Id: stepContext.context.activity.conversation.id, 
//                                               timestamp: stepContext.context.activity.timestamp,
//                                                Query :stepContext.context.activity.value.Query,
//                                                Category:stepContext.context.activity.value.Category,
//                                                Feedback: stepContext.context.activity.value.Feedback } });
//                 stepContext.context.sendActivity("Sorry for the inconvenience happened. Thanks for your feedback. You can contact the support link at [XXXX](XXXX) for further assistance.");
//                 this.stepContext.endDialog();
//             }


//             if (!bookingDetails && d!="yes" && d!= "no") {

//                 let searchDetails = {};

//                 await stepContext.beginDialog("AzureSearch", stepContext.context);

//               //  return await stepContext.endDialog();

//                    }
//              else if(d =="yes")
//                    {

//                       stepContext.context.sendActivity("Thanks.");
//                       //console.log("hmmmhmmmhmmmhmmm");
//                       const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
//                    await timeout(100);

//      const wel = CardFactory.adaptiveCard(WelcomeCard);
//       await stepContext.context.sendActivity({ attachments: [wel] });
//       //console.log("yuioppoiuyyyy",stepContext.context.activity);
//       //console.log("qwerty",stepContext.context.activity.text);
//       appInsightsClient.trackEvent({ name: "successEvents", properties: { success: stepContext.context.activity.text, 
//                                              conversation_Id: stepContext.context.activity.conversation.id, 
//                                               timestamp: stepContext.context.activity.timestamp
//                                                 } });

//    }
//              else if(d == "no")
//                    {
//                       var card3 = 
//                        {
//                         "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
//                         "type": "AdaptiveCard",
//                         "version": "1.0",
//                         "body": [
//                           {
//                             "type": "TextBlock",
//                             "text": "",
//                             "size": "large",
//                             "weight": "bolder"
//                           },
//                           {
//                             "type": "Input.Text",
//                             "placeholder": "Please rephrase your query here",
//                             "style": "text",
//                             "isMultiline": true,
//                             "maxLength": 0,
//                             "id": "Query"
//                           },
//                           {
//                             "type": "Input.ChoiceSet",
//                             "id": "Category",
//                             "style": "compact",
//                             "placeholder": "Select the category of query.",
//                             "choices": [
//                               {
//                                 "title": "Functional",
//                                 "value": "Functional"
//                               },
//                               {
//                                 "title": "Trouble Shooting",
//                                 "value": "Trouble Shooting"
//                               },
//                               {
//                                 "title": "Training",
//                                 "value": "Training"
//                               }
//                             ]
//                           },
//                              {
//                             "type": "Input.Text",
//                             "placeholder": "Please enter your feedback here",
//                             "style": "text",
//                             "isMultiline": true,
//                             "maxLength": 0,
//                             "id": "Feedback"
//                           }
//                         ],
//                         "actions": [
//                           {
//                             "type": "Action.Submit",
//                             "title": "Submit",
//                             "data": {
//                               "x": "Submit"
//                             }
//                           }
//                         ]
//                       };

//                 //console.log("mmmmmmmmmmmmmmmm",stepContext.context.activity);       


//                 const welcomeCard1 = CardFactory.adaptiveCard(card3);
//                 await stepContext.context.sendActivity({ attachments: [welcomeCard1] });     


//     ////console.log("llllllllllllllllllllllllllll");


//         }

//       // //console.log("llllllllllllllllllllllllllll",stepContext.context.activity);
//         }

// ////console.log("lllllllllllll22222222222",stepContext.context.activity);
//     }
// }

//     module.exports.MainDialog = MainDialog;


var restify = require('restify');
var builder = require('botbuilder');
var request = require("request");
var botbuilder_azure = require("botbuilder-azure");
var https = require('https');
var dateTime = require('node-datetime');
var pdfjsLib = require('pdfjs-dist');
var unzip = require('unzip')
var fs = require('fs');
//var {
//     AzureSearch
// } = require('./azure-search.js');

//var t1, t2;

var appInsights = require('applicationinsights');
appInsights.setup(process.env.BotDevAppInsightsKey)
	.setAutoDependencyCorrelation(true)
	.setAutoCollectRequests(true)
	.setAutoCollectPerformance(true)
	.setAutoCollectExceptions(true)
	.setAutoCollectDependencies(true)
	.setUseDiskRetryCaching(true)
	.start();
var appInsightsClient = appInsights.defaultClient;

const WelcomeCard = require('./cards/welcome.json');
const {
	CardFactory,
	MessageFactory
} = require('botbuilder-core');
const {
	ActivityHandler
} = require('botbuilder');
const {
	TimexProperty
} = require('@microsoft/recognizers-text-data-types-timex-expression');
const {
	ComponentDialog,
	DialogSet,
	DialogTurnStatus,
	TextPrompt,
	WaterfallDialog
} = require('botbuilder-dialogs');
// const {
//     BookingDialog
// } = require('./bookingDialog');
// const {
//     LuisHelper
// } = require('./luisHelper');
const {
	QnA
} = require('./create-new-knowledge-base');
const MAIN_WATERFALL_DIALOG = 'mainWaterfallDialog';
const AZURESEARCH = 'AzureSearch';
//const BOOKING_DIALOG = 'bookingDialog';
const {
	AzureSearch
} = require('./azure-search');
const PRIVATE_CONVERSATION_DATA_PROPERTY = 'privateconversationData';


class MainDialog extends ComponentDialog {
	constructor(logger,privateconversationState) {
		super('MainDialog');

		if (!logger) {
			logger = console;
			logger.log('[MainDialog]: logger not passed in, defaulting to console');
		}

		this.logger = logger;
		this.privateconversationData = privateconversationState.createProperty(PRIVATE_CONVERSATION_DATA_PROPERTY);
		this.privateconversationState = privateconversationState;
		
		//console.log("90890980-0",privateconversationState);
		// Define the main dialog and its related components.
		// This is a sample "book a flight" dialog.
		this.addDialog(new TextPrompt('TextPrompt'))
			// .addDialog(new AzureSearch(AZURESEARCH))
			.addDialog(new WaterfallDialog(MAIN_WATERFALL_DIALOG, [
				this.introStep.bind(this),
				// this.actStep.bind(this),
				// this.finalStep.bind(this)
			]));

		this.initialDialogId = MAIN_WATERFALL_DIALOG;
	}

	async run(turnContext, accessor) {
		
    //   console.log("asdfasdfasdf",turnContext);
	//   console.log("121233311",turnContext.turnState);
		const dialogSet = new DialogSet(accessor);
		dialogSet.add(this);

		const dialogContext = await dialogSet.createContext(turnContext);
		const results = await dialogContext.continueDialog();
		if (results.status === DialogTurnStatus.empty) {
			await dialogContext.beginDialog(this.id);
		}
	}


	async introStep(stepContext) {
		var c = String(stepContext.context.activity.text);
		var d = c.toLowerCase();
		let bookingDetails = {};
		let x = {};
        const privateconversationData = await this.privateconversationData.get(stepContext.context, {});
		 console.log("privateconversationData",privateconversationData);
		 //console.log('rrrrrrr0000000',privateconversationData[-1]);
		// stepContext.context.privateConversationData
		//privateconversationData.array = {};
	//	console.log("90890980-0",privateconversationState);
		
        
		//console.log("BEFORE FIRST : ", stepContext.context.activity);
		//console.log("ppppppppqqqqqrrr", d);
		if (!process.env.QnA_EndpointKey || !process.env.QnA_Host || !process.env.QnA_kb_Key) {
			await stepContext.context.sendActivity('NOTE: QnA is not configured. To enable all capabilities, add `QnA_EndpointKey`, `QnA_Host` and `QnA_kb_Key` to the .env file.');
			//return await stepContext.next();

		} else if (process.env.QnA_EndpointKey && process.env.QnA_Host && process.env.QnA_kb_Key) {

			// return await stepContext.beginDialog('create-new-knowledge-base', stepContext.context);
			bookingDetails = await QnA.executeQnAQuery(this.logger, stepContext.context);


			//console.log("BEFORE : ", stepContext.context.activity);
			this.logger.log('QnA extracted these booking details:', bookingDetails);


			if (stepContext.context.activity.value) {

				//console.log("hyyyyyy", stepContext.context.activity.from.name);
				//console.log("whyeeeeeeeee", stepContext.context.activity.conversation.id);
				//console.log("piiiiiiiii", stepContext.context.activity.timestamp);
				//console.log("assssssssssssssddddddddddff", stepContext.context.activity.text);
				//console.log("byeeeeeeeeeeee", stepContext.context.activity.value);
				//console.log("zzzzzzz", stepContext.context.activity.value.Query);
				//console.log("zzzzzzz", stepContext.context.activity.value.Category);
				//console.log("zzzzzzz", stepContext.context.activity.value.Feedback);
				//var xxxx = https://dev53970.service-now.com/sp?id=ticket&table=incident&sys_id=3ad52d83379733003dcbd02783990e4f;

				appInsightsClient.trackEvent({
					name: "Failure_Details",
					properties: {
						conversation_Id: stepContext.context.activity.conversation.id,
						timestamp: stepContext.context.activity.timestamp,
						Query: stepContext.context.activity.value.Query,
						Category: stepContext.context.activity.value.Category,
						Feedback: stepContext.context.activity.value.Feedback
					}
				});
				stepContext.context.sendActivity("Sorry for this inconvenience. Thanks for your feedback. For further assistance please click the support link [https://dev53970.service-now.com/sp?id=index](https://dev53970.service-now.com/sp?id=index)");
				this.stepContext.endDialog();
			}


			if (!bookingDetails && d != "yes" && d != "no") {
				// appInsightsClient.trackEvent({
				// 	name: "EveryEvent",
				// 	properties: {
				// 		input: stepContext.context.activity.text,
				// 		conversation_Id: stepContext.context.activity.conversation.id,
				// 		timestamp: stepContext.context.activity.timestamp
				// 	}
				// });

				// let searchDetails = {};
				x = await AzureSearch.RecommededName(stepContext.context);

				var y = stepContext.context.activity;
                
             //   privateconversationData.array = stepContext.context.activity.text;
                //console.log("prev:",privateconversationData);
				//console.log("BEFORE : ", privateconversationData.array);
			
				// //console.log("searchhhhh:", stepContext.context);
				// //console.log("hellhell", stepContext.context._respondedRef.responded);
				//this.logger.log('search extracted these booking details:',x);
				var xr = String(stepContext.context._respondedRef.responded);
				//console.log("ppppooyyyyrr", xr);
				if (xr == "false") {
					//console.log("8888888888888888");
					stepContext.context.sendActivity("Sorry! I couldn't understand the question.Please type a valid query.");
					//console.log("hmmmhmmmhmmmhmmm");
					const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
					await timeout(300);
					const wel = CardFactory.adaptiveCard(WelcomeCard);
					await stepContext.context.sendActivity({
						attachments: [wel]
					});
				} else if (xr == "true") {
					var card45 = {
						"$schema":   "http://adaptivecards.io/schemas/adaptive-card.json",
						"type":   "AdaptiveCard",
						"version":   "1.0",
						"body": [{
							"type":   "TextBlock",
							"text":   "Are you satisfied with the answer?",
							"size":   "Large",
							//"weight": "Bolder"
						}],
						"actions": [{
								"type":   "Action.Submit",
								"title":   "Yes",
								"data": "Yes"
							},
							{
								"type":   "Action.Submit",
								"title":   "No",
								"data": "No"
							}
						]
					};
					//console.log("qqqqqqqqqq");


					const wce = CardFactory.adaptiveCard(card45);
					await stepContext.context.sendActivity({
						attachments: [wce]
					});
					//console.log("qwerty");
				}
			}
			//await stepContext.beginDialog("AzureSearch", stepContext.context);

			//  return await stepContext.endDialog();
			else if (d == "yes") {
				
			//const	t2 = privateconversationData.array.slice(-1)[0];
				//console.log("TTTTT:",t2);
				//privateconversationData.b= t2;
				//console.log("TTTTT:",privateconversationData.array);


				stepContext.context.sendActivity("Thanks.");
				//console.log("hmmmhmmmhmmmhmmm");
				const timeout = ms => new Promise(resolve => setTimeout(resolve, ms));
				await timeout(300);

				const wel = CardFactory.adaptiveCard(WelcomeCard);
				await stepContext.context.sendActivity({
					attachments: [wel]
				});
				console.log("sssssss", t2);
				//console.log("qwerty", stepContext.context.activity.text);
				appInsightsClient.trackEvent({
					name: "successEvents",
					properties: {
						//Query: privateconversationData.array,
						conversation_Id: stepContext.context.activity.conversation.id,
						timestamp: stepContext.context.activity.timestamp
					}
				});

			} else if (d == "no") {
				console.log("ARRAY:",privateconversationData.array);
			// const	t1 = privateconversationData.array.slice(-1)[0];
			//     privateconversationData.a= t1;
			// 	console.log("TTTTT:",t1,privateconversationData.a);
			var z = String(privateconversationData);
				var card3 = {
					"$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
					"type": "AdaptiveCard",
					"version": "1.0",
					"body": [{
							"type": "TextBlock",
							"text": "",
							"size": "large",
							"weight": "bolder"
						},
						{
							"type": "Input.Text",
							"placeholder": "Please rephrase your query here",
							"value": z,
							"style": "text",
							"isMultiline": true,
							"maxLength": 0,
							"id": "Query"
						},
						{
							"type": "Input.ChoiceSet",
							"id": "Category",
							"style": "compact",
							"placeholder": "Select the category of query.",
							"choices": [{
									"title": "Functional",
									"value": "Functional"
								},
								{
									"title": "Trouble Shooting",
									"value": "Trouble Shooting"
								},
								{
									"title": "Training",
									"value": "Training"
								}
							]
						},
						{
							"type": "Input.Text",
							"placeholder": "Please enter your feedback here",
							"style": "text",
							"isMultiline": true,
							"maxLength": 0,
							"id": "Feedback"
						}
					],
					"actions": [{
						"type": "Action.Submit",
						"title": "Submit",
						"data": {
							"x": "Submit"
						}
					}]
				};

				//console.log("mmmmmmmmmmmmmmmm", stepContext.context.activity);


				const welcomeCard1 = CardFactory.adaptiveCard(card3);
				await stepContext.context.sendActivity({
					attachments: [welcomeCard1]
				});
 

				////console.log("llllllllllllllllllllllllllll");


			}

			// //console.log("llllllllllllllllllllllllllll",stepContext.context.activity);
		}

		////console.log("lllllllllllll22222222222",stepContext.context.activity);
		// await this.privateconversationState.saveChanges(stepContext.context, false);
		// console.log("asdfghjkl",stepContext.context);
		console.log("qazxswedc",privateconversationData-1);
	}
}

module.exports.MainDialog = MainDialog;
