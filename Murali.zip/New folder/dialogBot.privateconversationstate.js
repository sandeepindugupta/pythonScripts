// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { ActivityHandler } = require('botbuilder');

const { CardFactory } = require('botbuilder-core');
const WelcomeCard = require('./resources/welcomeCard.json');

class DialogBot extends ActivityHandler {
    /**
     *
     * @param {ConversationState} conversationState
     * @param {UserState} userState
     * @param {Dialog} dialog
     * @param {any} logger object for logging events, defaults to console if none is provided
     */
    constructor(privateconversationState, conversationState, userState, dialog, logger) {
        super();
        if(!privateconversationState) throw new Error('[DialogBot]: Missing parameter. privateconversationState is required');
        if (!conversationState) throw new Error('[DialogBot]: Missing parameter. conversationState is required');
        if (!userState) throw new Error('[DialogBot]: Missing parameter. userState is required');
        if (!dialog) throw new Error('[DialogBot]: Missing parameter. dialog is required');
        if (!logger) {
            logger = console;
            logger.log('[DialogBot]: logger not passed in, defaulting to console');
        }
        
         this.conversationData = conversationState.createProperty('conversationData');

        this.conversationState = conversationState;
        this.privateconversationData = privateconversationState.createProperty('privateconversationData');
		thi-s.privateconversationState = privateconversationState;
        this.userState = userState;
        this.dialog = dialog;
        this.logger = logger;
        this.dialogState = this.conversationState.createProperty('DialogState');

        this.onMessage(async (context, next) => {
            this.logger.log('Running dialog with Message Activity.');
            console.log("DIALOGBOT:",context.activity.text)
            
            const conversationData = await this.conversationData.get(
        context, {});
        const privateconversationData = await this.privateconversationData.get(context, {});
		 console.log("privateconversationData",privateconversationData);

        conversationData.sample = [];
        var user_text = context.activity.text;
        conversationData.sample.push(user_text);
        
        console.log("BOTTTTT:",conversationData);

            // Run the Dialog with the new message Activity.
            await this.dialog.run(context, this.dialogState);

            // By calling next() you ensure that the next BotHandler is run.
            await next();
        });
        
        this.onEvent(async (context, next) => {
            const eventName = context.activity.name;
            console.log("ppppppppppppppppppppp",context.activity.name);
           if (eventName === "reloadButtonClicked"){
            const welcomeCard = CardFactory.adaptiveCard(WelcomeCard);
            await context.sendActivity({ attachments: [welcomeCard] });
    //         bot.on('event', function(message) { 
  // if(context.name == 'reloadButtonClicked'){
    // bot.beginDialog(context.address, '');
   }
  await next();
});  
//});



// this.onEvent(async (context, next) => {
//             const eventName = context.activity.name;
//             console.log("ppppppppppppppppppppp",context.activity.name);
//            if (eventName === "submitButtonClicked"){
//                console.log("rrrrrrr");
//             //const welcomeCard = CardFactory.adaptiveCard(WelcomeCard);
//             //await context.sendActivity({ attachments: [welcomeCard] });
    
//    }
//   await next();
// });  


        

        this.onDialog(async (context, next) => {
            // Save any state changes. The load happened during the execution of the Dialog.
            await this.conversationState.saveChanges(context, false);
            await this.userState.saveChanges(context, false);
            
            console.log("DIALOGGGG:",conversationState);
            console.log("privateconversationstate:",privateconversationState);


            // By calling next() you ensure that the next BotHandler is run.
            await next();
        });
    }
}

module.exports.DialogBot = DialogBot;
